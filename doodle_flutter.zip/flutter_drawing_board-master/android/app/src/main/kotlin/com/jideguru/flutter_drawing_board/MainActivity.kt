package com.jideguru.flutter_drawing_board

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
