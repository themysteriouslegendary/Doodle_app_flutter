//GENERATED BARREL FILE
export 'current_stroke_value_notifier.dart';
